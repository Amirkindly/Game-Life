# RealLife (APK)
Push to GitHub (branch main). Actions tab -> Build APK -> Artifacts -> app-debug-apk.
